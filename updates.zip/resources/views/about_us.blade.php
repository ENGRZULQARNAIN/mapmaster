@extends('master')
@section('content')
<body class="leading-normal tracking-normal text-indigo-400   bg-cover bg-fixed"
    style="background-image: url('{{ asset('header.png') }}');">
    <div class="h-full">
        @include('navbar')

        <!--Main Section-->
        <div class="container pt-24 pb-5 md:pt-36 mx-auto flex flex-wrap flex-col items-center">
            <!--Left Col-->
            <div class="text-center w-full xl:w-2/5 overflow-y-hidden fade-in">
                <h1 class="my-4 text-4xl md:text-6xl text-white opacity-90 font-bold leading-tight space-y-4">
                    Stunning
                    <span
                        class="bg-clip-text text-transparent bg-gradient-to-r from-green-400 via-pink-500 to-purple-500">
                        2D & 3D Home Designs
                    </span>
                    for Modern Living!
                </h1>
            </div>
        </div>

        <section class="bg-white py-16">
            <h1 class="my-4 text-4xl text-center md:text-6xl text-white font-bold leading-tight space-y-4">
                <span
                    class="bg-clip-text text-transparent bg-gradient-to-r from-green-400 via-pink-500 to-purple-500 fade-in"">
                    About Us
                </span>
            </h1>
          <p class="px-16 text-black fade-in">
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, harum. Provident, necessitatibus est? Sint, laborum animi? Nobis rerum, dolor tempore quas temporibus reiciendis distinctio magni. Sint quae placeat nemo molestias?
          </p>
        </section>


        <div class="mt-16"></div>
@endsection